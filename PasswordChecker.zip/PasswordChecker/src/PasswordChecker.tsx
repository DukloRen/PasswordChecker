//interface
interface PasswordCheckerProps {
    passwordLength: number;
    password: string;
}

//function
export function PasswordChecker(props: PasswordCheckerProps) {
    //regex for the password
    const regexPassword = /^[a-z]+$/gmi;
    if (props.passwordLength < 8) {
        return <p style={{color: 'red'}}>Weak password</p>
    } else if (regexPassword.test(props.password)) {
        return <p style={{color: 'yellow'}}>Moderate password</p>
    } else {
        return <p style={{color: 'green'}}>Strong password</p>
    }
}
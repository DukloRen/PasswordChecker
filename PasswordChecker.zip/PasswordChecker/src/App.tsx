import { useState } from 'react'
import './App.css'
import { PasswordChecker } from './PasswordChecker'

function App() {
  const [password, setPassword] = useState('');

  return <div>
    <header style={{alignContent: 'top'}}>
      <img src="src\download.jpg" alt="gibbon"/>
      <h1>Jelszó ellenőrzés</h1>
    </header>
    
    <main>
      <input type="password" style={{background: 'red'}} onInput={e => {setPassword(e.currentTarget.value)}}/>
      <PasswordChecker passwordLength={password.length} password={password} />
    </main>

    <footer>
      <p><b>Készítette: Bárány Benedek<br></br> Dátum: 2024.01.15.</b></p>
    </footer>
  </div>
}

export default App
